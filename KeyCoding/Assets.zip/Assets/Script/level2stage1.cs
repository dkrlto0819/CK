﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class level2stage1 : MonoBehaviour {
    Canvas inputDataBox;
    //Text label;
	void Start () {
        inputDataBox = GameObject.Find("InputdataBox").GetComponent<Canvas>();
        Debug.Log(inputDataBox);
        inputDataBox.gameObject.SetActive(true);
        //label = GameObject.Find("Question").GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Awake()
    {
        //inputDataBox = GameObject.Find("InputdataBox").GetComponent<Canvas>();
    }

    public void Doit(){
        //inputBox = GameObject.Find("InputdataBox").GetComponent<Canvas>();
        //Debug.Log(inputDataBox);
        Debug.Log(inputDataBox);
        inputDataBox.gameObject.SetActive(true);
        //label.text = saveValue.resultFile;

    }
}
