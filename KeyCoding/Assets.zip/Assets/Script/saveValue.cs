﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class saveValue {
    public static string level, language;
    public static string stage;
    public static string resultFile = "";
}
